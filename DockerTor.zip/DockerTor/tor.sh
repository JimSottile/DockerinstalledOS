docker restart tor-browser
