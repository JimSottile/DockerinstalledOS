docker kill $(docker ps | grep tor-browser | awk '{print $1}')
